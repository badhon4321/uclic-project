"Outreque" is a humanist sans serif family, following the natural flow of the handwriting. The original idea was to make a typeface with a quirky design. And that's when the handwriting curves come into play. The name "Outreque" was taken from the word "outré", which is defined as "very unusual".
The family introduces 9 weights with matching slants. Bolder weights can be used for logos, heading, titles, and subtitles, while lighter weights, which increase legibility, work best for longer texts.

"Outreque" provides 12 styles free for personal and commercial uses. The other 6 styles will be paid.

If you want to donate, please send it to my Paypal account through the following link: https://paypal.me/randommaerks

Thank you for the support!